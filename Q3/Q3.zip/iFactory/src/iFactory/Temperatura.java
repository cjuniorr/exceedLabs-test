package iFactory;

public class Temperatura {

    public static void main(String[] args) {
        CalculaTemperatura Solution = new CalculaTemperatura();

        double[] ts = {7,-10,13,8,4,-7.2,-12,-3.7,3.5,-9.6,6.5,-1.7,-6.2,7};
   
        double result = Solution.closestToZero(ts);

        System.out.println("Result: " + result);
    }
}